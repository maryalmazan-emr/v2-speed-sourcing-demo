import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// ==================== UTILITY FUNCTIONS ====================

function generateInviteCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 10; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

function generateSessionToken(): string {
  return crypto.randomUUID();
}

function rankBids(bids: any[]): any[] {
  return bids.sort((a, b) => {
    // Primary: delivery_time ASC
    if (a.delivery_time !== b.delivery_time) {
      return a.delivery_time - b.delivery_time;
    }
    // Secondary: price ASC
    if (a.price !== b.price) {
      return a.price - b.price;
    }
    // Tertiary: created_at ASC (timestamp)
    return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
  });
}

// ==================== ROUTES ====================

// Health check endpoint
app.get("/make-server-923810f5/health", (c) => {
  return c.json({ status: "ok" });
});

// Debug endpoint - show database contents
app.get("/make-server-923810f5/debug", async (c) => {
  try {
    const auctionList = await kv.get("auction_list") || [];
    const debug = {
      auction_list: auctionList,
      auctions: [],
      invites: []
    };
    
    for (const auctionId of auctionList) {
      const auction = await kv.get(`auction:${auctionId}`);
      debug.auctions.push({ id: auctionId, auction });
      
      const inviteKeys = await kv.get(`auction_invites:${auctionId}`) || [];
      for (const inviteKey of inviteKeys) {
        const invite = await kv.get(`vendor_invite:${inviteKey}`);
        debug.invites.push({ 
          key: `vendor_invite:${inviteKey}`, 
          invite 
        });
      }
    }
    
    return c.json(debug);
  } catch (error) {
    console.log(`Error in debug endpoint: ${error}`);
    return c.json({ error: error.message }, 500);
  }
});

// Initialize with seed data
app.post("/make-server-923810f5/init", async (c) => {
  try {
    const auctionList = await kv.get("auction_list");
    if (auctionList && auctionList.length > 0) {
      return c.json({ message: "Already initialized" });
    }

    const auctionId = crypto.randomUUID();
    const now = new Date();
    const endsAt = new Date(now.getTime() + 48 * 60 * 60 * 1000);

    const sampleAuction = {
      id: auctionId,
      title: "Industrial Safety Equipment Supply",
      description: "We require industrial safety equipment including helmets, vests, and protective gear for our manufacturing facility.",
      quantity: 500,
      delivery_location: "Chicago, IL",
      notes: "Priority on delivery speed. Quality certifications required.",
      starts_at: now.toISOString(),
      ends_at: endsAt.toISOString(),
      status: "active",
      winner_vendor_email: null,
      created_by: "admin@example.com",
      created_at: now.toISOString()
    };

    await kv.set(`auction:${auctionId}`, sampleAuction);
    await kv.set("auction_list", [auctionId]);

    // Create test invites
    const testVendors = [
      { email: "vendor1@example.com", code: "V1-9G7K2LQX" },
      { email: "vendor2@example.com", code: "V2-8H4M9TJD" },
      { email: "vendor3@example.com", code: "V3-3P6R1AZW" }
    ];

    for (const vendor of testVendors) {
      const invite = {
        id: crypto.randomUUID(),
        auction_id: auctionId,
        email: vendor.email,
        invite_code: vendor.code,
        status: "pending",
        sent_at: null,
        accessed_at: null,
        created_at: now.toISOString()
      };
      await kv.set(`vendor_invite:${auctionId}:${vendor.email}`, invite);
    }

    const inviteList = testVendors.map(v => `${auctionId}:${v.email}`);
    await kv.set(`auction_invites:${auctionId}`, inviteList);

    return c.json({ message: "Initialized with seed data", auction: sampleAuction });
  } catch (error) {
    console.log(`Error initializing seed data: ${error}`);
    return c.json({ error: `Initialization failed: ${error.message}` }, 500);
  }
});

// Hard reset - wipe all data and create fresh seed data
app.post("/make-server-923810f5/reset", async (c) => {
  try {
    console.log("Starting hard reset...");
    
    // Get the auction list first to construct proper keys
    const auctionList = await kv.get("auction_list") || [];
    console.log(`Found ${auctionList.length} auctions to clean up`);
    
    // Build list of all keys to delete
    const keysToDelete = ["auction_list"];
    
    // For each auction, delete all related data
    for (const auctionId of auctionList) {
      keysToDelete.push(`auction:${auctionId}`);
      keysToDelete.push(`auction_invites:${auctionId}`);
      keysToDelete.push(`auction_bids:${auctionId}`);
      
      // Get invites for this auction to delete them
      const inviteList = await kv.get(`auction_invites:${auctionId}`) || [];
      for (const inviteKey of inviteList) {
        keysToDelete.push(`vendor_invite:${inviteKey}`);
      }
      
      // Get bids for this auction to delete them
      const bidList = await kv.get(`auction_bids:${auctionId}`) || [];
      for (const bidId of bidList) {
        keysToDelete.push(`bid:${bidId}`);
      }
    }
    
    // Also clean up any orphaned sessions (get all keys starting with vendor_session:)
    // Since we can't easily enumerate these without the key, we'll skip for now
    // The sessions will expire naturally
    
    console.log(`Deleting ${keysToDelete.length} keys...`);
    
    // Delete all keys
    if (keysToDelete.length > 0) {
      await kv.mdel(keysToDelete);
      console.log(`Deleted ${keysToDelete.length} keys`);
    }
    
    // Now create fresh seed data
    const auctionId = crypto.randomUUID();
    const now = new Date();
    const endsAt = new Date(now.getTime() + 48 * 60 * 60 * 1000);

    const sampleAuction = {
      id: auctionId,
      title: "Industrial Safety Equipment Supply",
      description: "We require industrial safety equipment including helmets, vests, and protective gear for our manufacturing facility.",
      quantity: 500,
      delivery_location: "Chicago, IL",
      notes: "Priority on delivery speed. Quality certifications required.",
      starts_at: now.toISOString(),
      ends_at: endsAt.toISOString(),
      status: "active",
      winner_vendor_email: null,
      created_by: "admin@example.com",
      created_at: now.toISOString()
    };

    await kv.set(`auction:${auctionId}`, sampleAuction);
    await kv.set("auction_list", [auctionId]);

    // Create test invites
    const testVendors = [
      { email: "vendor1@example.com", code: "V1-9G7K2LQX" },
      { email: "vendor2@example.com", code: "V2-8H4M9TJD" },
      { email: "vendor3@example.com", code: "V3-3P6R1AZW" }
    ];

    for (const vendor of testVendors) {
      const invite = {
        id: crypto.randomUUID(),
        auction_id: auctionId,
        email: vendor.email,
        invite_code: vendor.code,
        status: "pending",
        sent_at: null,
        accessed_at: null,
        created_at: now.toISOString()
      };
      await kv.set(`vendor_invite:${auctionId}:${vendor.email}`, invite);
    }

    const inviteList = testVendors.map(v => `${auctionId}:${v.email}`);
    await kv.set(`auction_invites:${auctionId}`, inviteList);

    console.log("Hard reset completed successfully");
    return c.json({ 
      message: "Hard reset completed - all data wiped and reseeded", 
      auction: sampleAuction,
      deleted_keys: keysToDelete.length 
    });
  } catch (error) {
    console.log(`Error during hard reset: ${error}`);
    return c.json({ error: `Hard reset failed: ${error.message}` }, 500);
  }
});

// Close current auction (mark as manually closed, don't delete)
app.delete("/make-server-923810f5/auctions/:id", async (c) => {
  try {
    const auctionId = c.req.param("id");
    console.log(`Closing auction ${auctionId}...`);
    
    // Check if auction exists
    const auction = await kv.get(`auction:${auctionId}`);
    if (!auction) {
      return c.json({ error: "Auction not found" }, 404);
    }
    
    // Mark auction as manually closed instead of deleting
    auction.status = 'manually_closed';
    auction.closed_at = new Date().toISOString();
    await kv.set(`auction:${auctionId}`, auction);
    
    console.log(`Successfully closed auction ${auctionId}`);
    
    return c.json({ 
      message: "Auction closed successfully",
      closed_auction_id: auctionId
    });
  } catch (error) {
    console.log(`Error closing auction: ${error}`);
    return c.json({ error: `Failed to close auction: ${error.message}` }, 500);
  }
});

// Get all auctions
app.get("/make-server-923810f5/auctions", async (c) => {
  try {
    const auctionList = await kv.get("auction_list") || [];
    const auctions = [];
    
    for (const auctionId of auctionList) {
      const auction = await kv.get(`auction:${auctionId}`);
      if (auction) {
        auctions.push(auction);
      }
    }

    return c.json({ auctions });
  } catch (error) {
    console.log(`Error fetching auctions: ${error}`);
    return c.json({ error: `Failed to fetch auctions: ${error.message}` }, 500);
  }
});

// Get auction by ID
app.get("/make-server-923810f5/auctions/:id", async (c) => {
  try {
    const auctionId = c.req.param("id");
    const auction = await kv.get(`auction:${auctionId}`);
    
    if (!auction) {
      return c.json({ error: "Auction not found" }, 404);
    }

    return c.json({ auction });
  } catch (error) {
    console.log(`Error fetching auction: ${error}`);
    return c.json({ error: `Failed to fetch auction: ${error.message}` }, 500);
  }
});

// Create auction
app.post("/make-server-923810f5/auctions", async (c) => {
  try {
    const body = await c.req.json();
    const auctionId = crypto.randomUUID();
    const now = new Date();
    
    // Use provided dates or default to now and 48 hours from now
    const startsAt = body.starts_at ? new Date(body.starts_at) : now;
    const endsAt = body.ends_at ? new Date(body.ends_at) : new Date(now.getTime() + 48 * 60 * 60 * 1000);

    const auction = {
      id: auctionId,
      title: body.title,
      description: body.description,
      quantity: body.quantity || null,
      delivery_location: body.delivery_location || null,
      notes: body.notes || null,
      starts_at: startsAt.toISOString(),
      ends_at: endsAt.toISOString(),
      status: body.status || "active",
      winner_vendor_email: null,
      // New fields from requirements
      date_requested: body.date_requested || now.toISOString().split('T')[0],
      requestor: body.requestor || null,
      requestor_email: body.requestor_email || null,
      group_site: body.group_site || null,
      event_type: body.event_type || null,
      target_lead_time: body.target_lead_time || null,
      part_numbers: body.part_numbers || null,
      created_at: now.toISOString(),
      updated_at: now.toISOString()
    };

    await kv.set(`auction:${auctionId}`, auction);
    
    // Update auction list
    const auctionList = await kv.get("auction_list") || [];
    auctionList.push(auctionId);
    await kv.set("auction_list", auctionList);

    return c.json({ auction }, 201);
  } catch (error) {
    console.log(`Error creating auction: ${error}`);
    return c.json({ error: `Failed to create auction: ${error.message}` }, 500);
  }
});

// Update auction status / select winner
app.put("/make-server-923810f5/auctions/:id", async (c) => {
  try {
    const auctionId = c.req.param("id");
    const body = await c.req.json();
    
    const auction = await kv.get(`auction:${auctionId}`);
    if (!auction) {
      return c.json({ error: "Auction not found" }, 404);
    }

    const updatedAuction = {
      ...auction,
      ...body,
      updated_at: new Date().toISOString()
    };

    await kv.set(`auction:${auctionId}`, updatedAuction);
    return c.json({ auction: updatedAuction });
  } catch (error) {
    console.log(`Error updating auction: ${error}`);
    return c.json({ error: `Failed to update auction: ${error.message}` }, 500);
  }
});

// Get invites for an auction
app.get("/make-server-923810f5/auctions/:id/invites", async (c) => {
  try {
    const auctionId = c.req.param("id");
    const inviteKeys = await kv.get(`auction_invites:${auctionId}`) || [];
    const invites = [];

    for (const key of inviteKeys) {
      const invite = await kv.get(`vendor_invite:${key}`);
      if (invite) {
        invites.push(invite);
      }
    }

    return c.json({ invites });
  } catch (error) {
    console.log(`Error fetching invites: ${error}`);
    return c.json({ error: `Failed to fetch invites: ${error.message}` }, 500);
  }
});

// Create invites for an auction
app.post("/make-server-923810f5/auctions/:id/invites", async (c) => {
  try {
    const auctionId = c.req.param("id");
    const body = await c.req.json();
    const invites = body.invites || []; // Array of { email, invite_code }
    const mode = body.mode || "prototype"; // "prototype" or "email"

    const auction = await kv.get(`auction:${auctionId}`);
    if (!auction) {
      return c.json({ error: "Auction not found" }, 404);
    }

    const inviteKeys = await kv.get(`auction_invites:${auctionId}`) || [];
    const createdInvites = [];

    for (const inviteData of invites) {
      const invite = {
        id: crypto.randomUUID(),
        auction_id: auctionId,
        email: inviteData.email,
        invite_code: inviteData.invite_code,
        supplier_name: inviteData.supplier_name || null,
        contact_name: inviteData.contact_name || null,
        contact_phone: inviteData.contact_phone || null,
        status: mode === "email" ? "sent" : "pending",
        sent_at: mode === "email" ? new Date().toISOString() : null,
        accessed_at: null,
        created_at: new Date().toISOString()
      };

      const key = `${auctionId}:${inviteData.email}`;
      await kv.set(`vendor_invite:${key}`, invite);
      inviteKeys.push(key);
      createdInvites.push(invite);
    }

    await kv.set(`auction_invites:${auctionId}`, inviteKeys);

    return c.json({ invites: createdInvites }, 201);
  } catch (error) {
    console.log(`Error creating invites: ${error}`);
    return c.json({ error: `Failed to create invites: ${error.message}` }, 500);
  }
});

// Get all invites (for Accounts page)
app.get("/make-server-923810f5/invites", async (c) => {
  try {
    const auctionList = await kv.get("auction_list") || [];
    const allInvites = [];

    for (const auctionId of auctionList) {
      const inviteKeys = await kv.get(`auction_invites:${auctionId}`) || [];
      
      for (const key of inviteKeys) {
        const invite = await kv.get(`vendor_invite:${key}`);
        if (invite) {
          const auction = await kv.get(`auction:${auctionId}`);
          allInvites.push({
            ...invite,
            auction_title: auction ? auction.title : "Unknown"
          });
        }
      }
    }

    return c.json({ invites: allInvites });
  } catch (error) {
    console.log(`Error fetching all invites: ${error}`);
    return c.json({ error: `Failed to fetch invites: ${error.message}` }, 500);
  }
});

// Vendor login
app.post("/make-server-923810f5/vendor/login", async (c) => {
  try {
    const body = await c.req.json();
    const { email, invite_code } = body;

    console.log(`Vendor login attempt - Email: ${email}, Code: ${invite_code}`);

    if (!email || !invite_code) {
      return c.json({ error: "Email and invite code required" }, 400);
    }

    // Find matching invite
    const auctionList = await kv.get("auction_list") || [];
    console.log(`Auction list:`, auctionList);
    
    let matchedInvite = null;
    let matchedAuctionId = null;

    for (const auctionId of auctionList) {
      const inviteKey = `vendor_invite:${auctionId}:${email}`;
      console.log(`Checking key: ${inviteKey}`);
      
      const invite = await kv.get(inviteKey);
      console.log(`Found invite:`, invite);
      
      if (invite && invite.invite_code === invite_code) {
        console.log(`✓ Match found for ${email}`);
        matchedInvite = invite;
        matchedAuctionId = auctionId;
        break;
      } else if (invite) {
        console.log(`✗ Invite exists but code mismatch. Expected: ${invite.invite_code}, Got: ${invite_code}`);
      } else {
        console.log(`✗ No invite found at key: ${inviteKey}`);
      }
    }

    if (!matchedInvite) {
      console.log(`Login failed - no matching invite found for ${email}`);
      return c.json({ error: "Invalid email or invite code" }, 401);
    }

    // Update invite accessed timestamp
    matchedInvite.accessed_at = new Date().toISOString();
    matchedInvite.status = "accessed";
    await kv.set(`vendor_invite:${matchedAuctionId}:${email}`, matchedInvite);

    // Create session
    const sessionToken = generateSessionToken();
    const session = {
      vendor_email: email,
      auction_id: matchedAuctionId,
      session_token: sessionToken,
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24h
      created_at: new Date().toISOString()
    };

    await kv.set(`vendor_session:${sessionToken}`, session);

    console.log(`✓ Login successful for ${email}`);
    return c.json({ session, auction_id: matchedAuctionId });
  } catch (error) {
    console.log(`Error during vendor login: ${error}`);
    return c.json({ error: `Login failed: ${error.message}` }, 500);
  }
});

// Verify vendor session
app.post("/make-server-923810f5/vendor/verify", async (c) => {
  try {
    const body = await c.req.json();
    const { session_token } = body;

    if (!session_token) {
      return c.json({ error: "Session token required" }, 400);
    }

    const session = await kv.get(`vendor_session:${session_token}`);
    if (!session) {
      return c.json({ error: "Invalid session" }, 401);
    }

    // Check expiry
    if (new Date(session.expires_at) < new Date()) {
      return c.json({ error: "Session expired" }, 401);
    }

    return c.json({ session });
  } catch (error) {
    console.log(`Error verifying session: ${error}`);
    return c.json({ error: `Verification failed: ${error.message}` }, 500);
  }
});

// Get bids for an auction
app.get("/make-server-923810f5/auctions/:id/bids", async (c) => {
  try {
    const auctionId = c.req.param("id");
    const bidKeys = await kv.get(`auction_bids:${auctionId}`) || [];
    const bids = [];

    for (const key of bidKeys) {
      const bid = await kv.get(`bid:${key}`);
      if (bid) {
        bids.push(bid);
      }
    }

    // Rank bids
    const rankedBids = rankBids(bids);
    
    return c.json({ bids: rankedBids });
  } catch (error) {
    console.log(`Error fetching bids: ${error}`);
    return c.json({ error: `Failed to fetch bids: ${error.message}` }, 500);
  }
});

// Create/Update bid
app.post("/make-server-923810f5/auctions/:id/bids", async (c) => {
  try {
    const auctionId = c.req.param("id");
    const body = await c.req.json();
    const { vendor_email, delivery_time, price, session_token, company_name, contact_name, contact_phone } = body;

    // Verify session
    const session = await kv.get(`vendor_session:${session_token}`);
    if (!session || session.vendor_email !== vendor_email || session.auction_id !== auctionId) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Check if auction is active
    const auction = await kv.get(`auction:${auctionId}`);
    if (!auction || auction.status !== "active") {
      return c.json({ error: "Auction is not active" }, 400);
    }

    // Check if auction has ended
    if (new Date(auction.ends_at) < new Date()) {
      return c.json({ error: "Auction has ended" }, 400);
    }

    const bidKeys = await kv.get(`auction_bids:${auctionId}`) || [];
    const bidKey = `${auctionId}:${vendor_email}`;
    
    // Check if bid exists
    const existingBid = await kv.get(`bid:${bidKey}`);
    
    const bid = {
      id: existingBid?.id || crypto.randomUUID(),
      auction_id: auctionId,
      vendor_email,
      delivery_time,
      price,
      company_name: company_name || existingBid?.company_name || null,
      contact_name: contact_name || existingBid?.contact_name || null,
      contact_phone: contact_phone || existingBid?.contact_phone || null,
      created_at: existingBid?.created_at || new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    await kv.set(`bid:${bidKey}`, bid);

    // Update bid list if new
    if (!existingBid) {
      bidKeys.push(bidKey);
      await kv.set(`auction_bids:${auctionId}`, bidKeys);
    }

    return c.json({ bid });
  } catch (error) {
    console.log(`Error creating/updating bid: ${error}`);
    return c.json({ error: `Failed to save bid: ${error.message}` }, 500);
  }
});

// Get vendor's own bid and rank
app.get("/make-server-923810f5/auctions/:id/vendor-status", async (c) => {
  try {
    const auctionId = c.req.param("id");
    const sessionToken = c.req.query("session_token");

    if (!sessionToken) {
      return c.json({ error: "Session token required" }, 400);
    }

    const session = await kv.get(`vendor_session:${sessionToken}`);
    if (!session || session.auction_id !== auctionId) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const vendorEmail = session.vendor_email;

    // Get all bids
    const bidKeys = await kv.get(`auction_bids:${auctionId}`) || [];
    const bids = [];

    for (const key of bidKeys) {
      const bid = await kv.get(`bid:${key}`);
      if (bid) {
        bids.push(bid);
      }
    }

    // Rank bids
    const rankedBids = rankBids(bids);

    // Find vendor's bid and rank
    const vendorBidIndex = rankedBids.findIndex(b => b.vendor_email === vendorEmail);
    const vendorBid = vendorBidIndex >= 0 ? rankedBids[vendorBidIndex] : null;
    const rank = vendorBid ? vendorBidIndex + 1 : null;

    // Get leading metrics
    const leadingBid = rankedBids.length > 0 ? rankedBids[0] : null;

    return c.json({
      vendor_bid: vendorBid,
      rank,
      total_bids: rankedBids.length,
      leading_delivery_time: leadingBid ? leadingBid.delivery_time : null,
      leading_price: leadingBid ? leadingBid.price : null
    });
  } catch (error) {
    console.log(`Error fetching vendor status: ${error}`);
    return c.json({ error: `Failed to fetch status: ${error.message}` }, 500);
  }
});

// Get supplier history for autocomplete
app.get("/make-server-923810f5/suppliers/history", async (c) => {
  try {
    const suppliers = await kv.get("supplier_history") || [];
    return c.json({ suppliers });
  } catch (error) {
    console.log(`Error fetching supplier history: ${error}`);
    return c.json({ error: `Failed to fetch supplier history: ${error.message}` }, 500);
  }
});

// Save suppliers to history
app.post("/make-server-923810f5/suppliers", async (c) => {
  try {
    const body = await c.req.json();
    const newSuppliers = body.suppliers || [];
    
    // Get existing history
    const existingSuppliers = await kv.get("supplier_history") || [];
    
    // Merge new suppliers with existing, avoiding duplicates by email
    const supplierMap = new Map();
    
    // Add existing suppliers first
    existingSuppliers.forEach((s: any) => {
      supplierMap.set(s.contact_email, s);
    });
    
    // Add/update with new suppliers
    newSuppliers.forEach((s: any) => {
      if (s.contact_email) {
        supplierMap.set(s.contact_email, {
          ...s,
          last_used: new Date().toISOString()
        });
      }
    });
    
    // Convert back to array
    const updatedSuppliers = Array.from(supplierMap.values());
    
    // Save to KV
    await kv.set("supplier_history", updatedSuppliers);
    
    return c.json({ suppliers: updatedSuppliers }, 201);
  } catch (error) {
    console.log(`Error saving suppliers: ${error}`);
    return c.json({ error: `Failed to save suppliers: ${error.message}` }, 500);
  }
});

// 404 handler - return JSON instead of HTML
app.notFound((c) => {
  return c.json({ error: 'Not Found', path: c.req.url }, 404);
});

// Error handler - return JSON for all errors
app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ 
    error: 'Internal Server Error', 
    message: err.message 
  }, 500);
});

Deno.serve(app.fetch);