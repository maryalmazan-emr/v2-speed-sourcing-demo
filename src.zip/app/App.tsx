import React, { useState, useEffect } from 'react';
import { Header } from '@/app/components/Header';
import { AdminSetup } from '@/app/components/AdminSetup';
import { AdminDashboard } from '@/app/components/AdminDashboard';
import { AdminLogin } from '@/app/components/AdminLogin';
import { VendorLogin } from '@/app/components/VendorLogin';
import { VendorDashboard } from '@/app/components/VendorDashboard';
import { AllAuctions } from '@/app/components/AllAuctions';
import { Accounts } from '@/app/components/Accounts';
import { ServerStatusError } from '@/app/components/ServerStatusError';
import { Toaster } from '@/app/components/ui/sonner';
import { toast } from 'sonner';
import { apiCall } from '@/lib/api';
import { createAdminAccount, validateAdminLogin, hasGlobalAccess, canDelete, getRoleName } from '@/lib/adminAuth';

type View = 'admin-login' | 'admin-setup' | 'admin-dashboard' | 'vendor-login' | 'vendor-dashboard' | 'all-auctions' | 'accounts';

export default function App() {
  const [role, setRole] = useState<'admin' | 'vendor'>('admin');
  const [view, setView] = useState<View>('admin-login');
  const [auction, setAuction] = useState<any>(null);
  const [vendorSession, setVendorSession] = useState<any>(null);
  const [adminSession, setAdminSession] = useState<any>(null);
  const [initialized, setInitialized] = useState(false);
  const [serverAvailable, setServerAvailable] = useState(true);

  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    try {
      console.log('Initializing app...');
      
      // Test if the Edge Function is available
      let isServerAvailable = false;
      try {
        const healthRes = await apiCall('/make-server-923810f5/health');
        if (healthRes.ok) {
          isServerAvailable = true;
          console.log('✓ Edge Function is running');
        }
      } catch (healthError) {
        console.warn('Edge Function health check failed:', healthError);
        isServerAvailable = false;
      }

      if (!isServerAvailable) {
        console.error('❌ Edge Function is not available. It may need to be deployed.');
        setServerAvailable(false);
        setInitialized(true);
        return;
      }

      setServerAvailable(true);
      
      // Don't auto-load auctions - user must log in first
      // This ensures proper authentication and data isolation
      
      setInitialized(true);
      console.log('✓ App initialization complete');
    } catch (error) {
      console.error('Initialization error:', error);
      const errorMsg = error instanceof Error ? error.message : String(error);
      
      if (errorMsg.includes('Edge Function may not be deployed')) {
        setServerAvailable(false);
        toast.error('Backend is not deployed yet. Please wait a moment and refresh.', {
          duration: 10000
        });
      } else {
        toast.error('Failed to initialize app. Check console for details.');
      }
      
      setInitialized(true);
    }
  };

  const handleRoleChange = (newRole: 'admin' | 'vendor') => {
    setRole(newRole);
    if (newRole === 'admin') {
      // Check if admin is logged in
      if (adminSession) {
        setView(auction ? 'admin-dashboard' : 'admin-setup');
      } else {
        setView('admin-login');
      }
      setVendorSession(null);
    } else {
      setView('vendor-login');
      setAdminSession(null);
    }
  };

  const handleAdminLogin = async (email: string, name: string, password: string, isNewAccount: boolean) => {
    try {
      let result;
      
      if (isNewAccount) {
        // Create new account
        result = createAdminAccount(email, name, password);
        if (!result.success) {
          toast.error(result.error || 'Failed to create account');
          return;
        }
        toast.success('Account created successfully!');
      } else {
        // Validate existing account
        result = validateAdminLogin(email, password);
        if (!result.success) {
          toast.error(result.error || 'Login failed');
          return;
        }
        toast.success('Logged in successfully');
      }
      
      // Store session
      const session = {
        email: result.account!.email,
        name: result.account!.name,
        password: result.account!.password,
        role: result.account!.role,
        timestamp: Date.now()
      };
      
      setAdminSession(session);
      
      // Show role-specific welcome message
      const roleName = getRoleName(result.account!.role);
      if (isNewAccount) {
        toast.success(`Welcome! You are now an ${roleName}`);
      } else {
        toast.success(`Welcome back, ${roleName}`);
      }
      
      setView('admin-setup');
    } catch (error: any) {
      console.error('Admin auth error:', error);
      toast.error(error.message || 'Failed to authenticate');
    }
  };

  const handleAdminLogout = () => {
    setAdminSession(null);
    setAuction(null);
    setView('admin-login');
    toast.info('Logged out successfully');
  };

  const handleNavigate = (target: string) => {
    if (target === 'all-auctions') {
      // Require login to view auction history
      if (!adminSession) {
        setView('admin-login');
        toast.info('Please log in to view auction history');
      } else {
        setView('all-auctions');
      }
    } else if (target === 'accounts') {
      // Require login to view accounts
      if (!adminSession) {
        setView('admin-login');
        toast.info('Please log in to view accounts');
      } else {
        setView('accounts');
      }
    }
  };

  const handleAuctionComplete = async () => {
    // Refresh auctions
    const auctionsRes = await apiCall('/make-server-923810f5/auctions');
    const auctionsData = await auctionsRes.json();
    
    if (auctionsData.auctions && auctionsData.auctions.length > 0) {
      const latestAuction = auctionsData.auctions[auctionsData.auctions.length - 1];
      setAuction(latestAuction);
      setView('admin-dashboard');
    }
    
    // Clear admin session after auction is created
    // This forces re-login for next auction
    setAdminSession(null);
  };

  const handleVendorLogin = (session: any, auctionId: string) => {
    setVendorSession(session);
    // Load the auction for this session
    loadAuction(auctionId);
    setView('vendor-dashboard');
  };

  const handleVendorLogout = () => {
    setVendorSession(null);
    setView('vendor-login');
    setAuction(null);
  };

  const loadAuction = async (auctionId: string) => {
    try {
      const res = await apiCall(`/make-server-923810f5/auctions/${auctionId}`);
      const data = await res.json();
      setAuction(data.auction);
    } catch (error) {
      console.error('Error loading auction:', error);
      toast.error('Failed to load auction');
    }
  };

  const handleSelectAuction = (selectedAuction: any) => {
    setAuction(selectedAuction);
    if (role === 'admin') {
      setView('admin-dashboard');
    }
  };

  const handleRefresh = () => {
    if (auction) {
      loadAuction(auction.id);
    }
  };

  const handleRetry = () => {
    setInitialized(false);
    setServerAvailable(true);
    initializeApp();
  };

  const handleResetAuction = async () => {
    // Clear admin session and require login to close auction
    setAdminSession(null);
    setAuction(null);
    setView('admin-login');
    toast.info('Please log in to close the auction');
  };

  const handleCreateAuction = () => {
    // Clear admin session and require login for new auction
    setAdminSession(null);
    setView('admin-login');
    toast.info('Please log in to create a new auction');
  };

  if (!initialized) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-xl font-semibold">Loading Speed Sourcing Portal...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {view !== 'vendor-login' && view !== 'admin-login' && (
        <Header
          auction={view === 'admin-dashboard' || view === 'vendor-dashboard' ? auction : null}
          role={role}
          onRoleChange={handleRoleChange}
          onNavigate={handleNavigate}
          onResetAuction={role === 'admin' ? handleResetAuction : undefined}
          onCreateAuction={role === 'admin' ? handleCreateAuction : undefined}
          onAdminLogout={role === 'admin' && adminSession ? handleAdminLogout : undefined}
          currentUser={adminSession ? adminSession.name || adminSession.email : undefined}
        />
      )}

      {view === 'admin-login' && (
        <AdminLogin onLogin={handleAdminLogin} />
      )}

      {view === 'admin-setup' && adminSession && (
        <AdminSetup onComplete={handleAuctionComplete} adminSession={adminSession} />
      )}

      {view === 'admin-dashboard' && auction && (
        <AdminDashboard
          auction={auction}
          onRefresh={handleRefresh}
        />
      )}

      {view === 'vendor-login' && (
        <VendorLogin onLogin={handleVendorLogin} />
      )}

      {view === 'vendor-dashboard' && auction && vendorSession && (
        <VendorDashboard
          auction={auction}
          session={vendorSession}
          onLogout={handleVendorLogout}
        />
      )}

      {view === 'all-auctions' && adminSession && (
        <AllAuctions
          onBack={() => setView(role === 'admin' ? (auction ? 'admin-dashboard' : 'admin-setup') : 'vendor-login')}
          onSelectAuction={handleSelectAuction}
          adminEmail={adminSession.email}
          adminPassword={adminSession.password}
          userRole={adminSession.role}
        />
      )}

      {view === 'accounts' && adminSession && (
        <Accounts
          onBack={() => setView(role === 'admin' ? (auction ? 'admin-dashboard' : 'admin-setup') : 'vendor-login')}
          adminEmail={adminSession.email}
          userRole={adminSession.role}
        />
      )}

      {!serverAvailable && <ServerStatusError onRetry={handleRetry} />}
      <Toaster position="top-center" />
    </div>
  );
}