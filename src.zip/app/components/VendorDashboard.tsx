import React, { useState, useEffect } from 'react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Trophy, TrendingUp, Award } from 'lucide-react';
import { toast } from 'sonner';
import { apiCall } from '@/lib/api';

interface VendorDashboardProps {
  auction: any;
  session: any;
  onLogout: () => void;
}

export function VendorDashboard({ auction, session, onLogout }: VendorDashboardProps) {
  const [deliveryTime, setDeliveryTime] = useState('');
  const [price, setPrice] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [status, setStatus] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showCompanyForm, setShowCompanyForm] = useState(false);

  useEffect(() => {
    if (auction && session) {
      loadStatus();
      const interval = setInterval(loadStatus, 5000); // Refresh every 5 seconds
      return () => clearInterval(interval);
    }
  }, [auction, session]);

  const loadStatus = async () => {
    try {
      const res = await apiCall(
        `/make-server-923810f5/auctions/${auction.id}/vendor-status?session_token=${session.session_token}`
      );
      
      if (!res.ok) throw new Error('Failed to load status');
      
      const data = await res.json();
      setStatus(data);
      
      if (data.vendor_bid) {
        setDeliveryTime(data.vendor_bid.delivery_time.toString());
        setPrice(data.vendor_bid.price.toString());
        // Load company info if available
        if (data.vendor_bid.company_name) {
          setCompanyName(data.vendor_bid.company_name);
          setContactName(data.vendor_bid.contact_name || '');
          setContactPhone(data.vendor_bid.contact_phone || '');
        } else {
          setShowCompanyForm(true); // Show form if no company info yet
        }
      } else {
        setShowCompanyForm(true); // Show form for first-time bidders
      }
    } catch (error) {
      console.error('Error loading status:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitBid = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate company info for first-time bidders
    if (showCompanyForm && (!companyName || !contactName)) {
      toast.error('Please provide your company name and contact name');
      return;
    }
    
    setSubmitting(true);

    try {
      const res = await apiCall(
        `/make-server-923810f5/auctions/${auction.id}/bids`,
        {
          method: 'POST',
          body: JSON.stringify({
            vendor_email: session.vendor_email,
            delivery_time: parseFloat(deliveryTime),
            price: parseFloat(price),
            company_name: companyName,
            contact_name: contactName,
            contact_phone: contactPhone,
            session_token: session.session_token
          })
        }
      );

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || 'Failed to submit bid');
      }

      toast.success('Bid submitted successfully!');
      setShowCompanyForm(false); // Hide company form after first submission
      loadStatus();
    } catch (error: any) {
      console.error('Bid submission error:', error);
      toast.error(error.message || 'Failed to submit bid');
    } finally {
      setSubmitting(false);
    }
  };

  const getRankBadge = () => {
    if (!status || !status.rank) return null;

    if (status.rank === 1) {
      return (
        <Badge className="bg-[#00573d] text-white border-0">
          <Trophy className="h-3 w-3 mr-1" />
          Leading
        </Badge>
      );
    } else if (status.rank === 2) {
      return (
        <Badge className="bg-[#004b8d] text-white border-0">
          <TrendingUp className="h-3 w-3 mr-1" />
          Close
        </Badge>
      );
    } else {
      return (
        <Badge className="bg-[#75787c] text-white border-0">
          <Award className="h-3 w-3 mr-1" />
          Improve
        </Badge>
      );
    }
  };

  const isAuctionActive = () => {
    if (!auction) return false;
    if (auction.status !== 'active') return false;
    const now = new Date();
    const startsAt = new Date(auction.starts_at);
    const endsAt = new Date(auction.ends_at);
    // Auction is active only if it has started and hasn't ended
    return now >= startsAt && endsAt > now;
  };

  const hasAuctionStarted = () => {
    if (!auction) return false;
    return new Date() >= new Date(auction.starts_at);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Vendor Dashboard</h1>
          <p className="text-sm text-gray-600">Logged in as: {session.vendor_email}</p>
        </div>
        <Button variant="outline" onClick={onLogout}>
          Logout
        </Button>
      </div>

      {/* Auction Details */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{auction.title}</CardTitle>
          <CardDescription>{auction.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            {auction.quantity && (
              <div>
                <span className="text-gray-600">Quantity:</span>
                <div className="font-semibold">{auction.quantity}</div>
              </div>
            )}
            {auction.delivery_location && (
              <div>
                <span className="text-gray-600">Delivery Location:</span>
                <div className="font-semibold">{auction.delivery_location}</div>
              </div>
            )}
            <div>
              <span className="text-gray-600\">Status:</span>
              <div>
                {!hasAuctionStarted() ? (
                  <Badge className="bg-[#f3f3f3] text-[#75787c] border border-[#dedfe0]">
                    Not Started
                  </Badge>
                ) : (
                  <Badge variant={isAuctionActive() ? 'default' : 'secondary'}>
                    {isAuctionActive() ? 'Active' : 'Ended'}
                  </Badge>
                )}
              </div>
            </div>
          </div>
          {auction.notes && (
            <div className="mt-4 p-3 bg-gray-50 rounded">
              <span className="text-sm text-gray-600">Notes:</span>
              <div className="text-sm mt-1">{auction.notes}</div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Your Rank Card */}
      {status && status.rank && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Your Rank</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-4xl font-bold text-blue-600">#{status.rank}</div>
                <div className="text-sm text-gray-600 mt-1">
                  out of {status.total_bids} bid{status.total_bids !== 1 ? 's' : ''}
                </div>
              </div>
              <div>{getRankBadge()}</div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Competitive Stats */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Competitive Stats (Anonymous)</CardTitle>
          <CardDescription>Leading metrics from all bids</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {status?.total_bids || 0}
              </div>
              <div className="text-sm text-gray-600">Total Bids</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {status?.leading_delivery_time ? `${status.leading_delivery_time} days` : 'N/A'}
              </div>
              <div className="text-sm text-gray-600">Leading Delivery</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {status?.leading_price ? `$${status.leading_price.toLocaleString()}` : 'N/A'}
              </div>
              <div className="text-sm text-gray-600">Leading Price</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bid Form */}
      <Card>
        <CardHeader>
          <CardTitle>
            {status?.vendor_bid ? 'Update Your Bid' : 'Submit Your Bid'}
          </CardTitle>
          <CardDescription>
            {!hasAuctionStarted()
              ? 'Auction has not started yet - bidding will open soon'
              : isAuctionActive()
              ? 'You can update your bid at any time during the auction'
              : 'Auction has ended - bids are now locked'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmitBid} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="delivery-time">Delivery Time (days) *</Label>
                <Input
                  id="delivery-time"
                  type="number"
                  step="0.1"
                  value={deliveryTime}
                  onChange={(e) => setDeliveryTime(e.target.value)}
                  placeholder="e.g., 7"
                  required
                  disabled={!isAuctionActive() || submitting}
                />
              </div>
              <div>
                <Label htmlFor="price">Price ($) *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="e.g., 15000"
                  required
                  disabled={!isAuctionActive() || submitting}
                />
              </div>
            </div>
            {showCompanyForm && (
              <div className="space-y-2">
                <Label htmlFor="company-name">Company Name *</Label>
                <Input
                  id="company-name"
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g., ABC Company"
                  required
                />
                <Label htmlFor="contact-name">Contact Name *</Label>
                <Input
                  id="contact-name"
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="e.g., John Doe"
                  required
                />
                <Label htmlFor="contact-phone">Contact Phone</Label>
                <Input
                  id="contact-phone"
                  type="text"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  placeholder="e.g., 123-456-7890"
                />
              </div>
            )}
            <Button
              type="submit"
              className="w-full"
              disabled={!isAuctionActive() || submitting}
            >
              {submitting ? 'Submitting...' : status?.vendor_bid ? 'Update Bid' : 'Submit Bid'}
            </Button>
            {!hasAuctionStarted() && (
              <p className="text-sm text-blue-600 text-center">
                ⏸️ Auction has not started yet. Please wait for the start time.
              </p>
            )}
            {hasAuctionStarted() && !isAuctionActive() && (
              <p className="text-sm text-amber-600 text-center">
                Auction has ended. No changes can be made.
              </p>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}