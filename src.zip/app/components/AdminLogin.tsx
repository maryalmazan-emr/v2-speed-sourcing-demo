import React, { useState, useEffect } from 'react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { toast } from 'sonner';
import { getAdminAccount } from '@/lib/adminAuth';

interface AdminLoginProps {
  onLogin: (email: string, name: string, password: string, isNewAccount: boolean) => void;
}

export function AdminLogin({ onLogin }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isNewAccount, setIsNewAccount] = useState(false);

  // Check if email exists when user types
  useEffect(() => {
    if (email && email.includes('@')) {
      const account = getAdminAccount(email);
      setIsNewAccount(!account);
      if (account) {
        setName(account.name); // Pre-fill name for existing accounts
      } else {
        setName(''); // Clear name for new accounts
      }
    }
  }, [email]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate Emerson email
    if (!email.toLowerCase().endsWith('@emerson.com')) {
      toast.error('Please use your Emerson email address (@emerson.com)');
      return;
    }

    if (isNewAccount && !name.trim()) {
      toast.error('Please enter your full name');
      return;
    }

    if (password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      onLogin(email, name, password, isNewAccount);
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">
            {isNewAccount ? 'Create Internal User Account' : 'Internal User Login'}
          </CardTitle>
          <CardDescription>
            {isNewAccount 
              ? 'Create your account to start managing auctions'
              : 'Welcome back! Please enter your credentials'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Emerson Email *</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="yourname@emerson.com"
                required
                autoComplete="email"
              />
              <p className="text-xs text-gray-500">Must be an @emerson.com email</p>
              {email && email.includes('@') && (
                <p className="text-xs text-blue-600">
                  {isNewAccount ? '✓ New account - please create a password' : '✓ Existing account - please enter your password'}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="John Smith"
                required
                autoComplete="name"
                disabled={!isNewAccount && !!name}
              />
              {!isNewAccount && name && (
                <p className="text-xs text-gray-500">Registered as: {name}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">
                {isNewAccount ? 'Create Password' : 'Password'} *
              </Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                autoComplete={isNewAccount ? 'new-password' : 'current-password'}
              />
              {isNewAccount && (
                <p className="text-xs text-gray-500">Minimum 6 characters. You'll use this password for all future logins.</p>
              )}
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={loading}
            >
              {loading ? 'Please wait...' : isNewAccount ? 'Create Account & Continue' : 'Log In'}
            </Button>

            {!isNewAccount && (
              <p className="text-xs text-center text-gray-500 mt-4">
                This is your permanent account. Use the same password you created during signup.
              </p>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}