import React, { useState, useEffect } from 'react';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Copy, Crown, Check } from 'lucide-react';
import { toast } from 'sonner';
import { apiCall } from '@/lib/api';
import { copyToClipboard } from '@/lib/clipboard';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/app/components/ui/table';

interface AdminDashboardProps {
  auction: any;
  onRefresh: () => void;
}

export function AdminDashboard({ auction, onRefresh }: AdminDashboardProps) {
  const [invites, setInvites] = useState<any[]>([]);
  const [bids, setBids] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Generate a readable short ID from the UUID
  const getShortId = (uuid: string) => {
    return uuid.substring(0, 8).toUpperCase();
  };

  useEffect(() => {
    if (auction) {
      loadData();
    }
  }, [auction]);

  const loadData = async () => {
    try {
      // Fetch invites
      const invitesRes = await apiCall(
        `/make-server-923810f5/auctions/${auction.id}/invites`
      );
      const invitesData = await invitesRes.json();
      setInvites(invitesData.invites || []);

      // Fetch bids
      const bidsRes = await apiCall(
        `/make-server-923810f5/auctions/${auction.id}/bids`
      );
      const bidsData = await bidsRes.json();
      setBids(bidsData.bids || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyCode = async (code: string) => {
    const success = await copyToClipboard(code);
    if (success) {
      toast.success('Code copied');
    } else {
      toast.error('Failed to copy to clipboard');
    }
  };

  const copyInvite = async (index: number) => {
    const invite = invites[index];
    const message = `You're invited to Reverse Auction: ${auction.title}

Portal URL: ${window.location.origin}
Email: ${invite.email}
Invite Code: ${invite.invite_code}

Please log in to submit your bid. The auction closes in 48 hours.`;

    const success = await copyToClipboard(message);
    if (success) {
      setCopiedIndex(index);
      toast.success('Invite copied to clipboard');
      setTimeout(() => setCopiedIndex(null), 2000);
    } else {
      toast.error('Failed to copy to clipboard');
    }
  };

  const selectWinner = async (vendorEmail: string) => {
    try {
      const res = await apiCall(
        `/make-server-923810f5/auctions/${auction.id}`,
        {
          method: 'PUT',
          body: JSON.stringify({
            status: 'awarded',
            winner_vendor_email: vendorEmail
          })
        }
      );

      if (!res.ok) throw new Error('Failed to select winner');
      toast.success('Winner selected successfully!');
      onRefresh();
    } catch (error) {
      console.error('Error selecting winner:', error);
      toast.error('Failed to select winner');
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  const leadingBid = bids.length > 0 ? bids[0] : null;

  return (
    <div className="container mx-auto px-4 py-8" style={{ maxWidth: '1180px' }}>
      {/* Auction Summary */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-mono text-[#9fa1a4] bg-[#f3f3f3] px-2 py-1 rounded">
                  ID: {getShortId(auction.id)}
                </span>
                {new Date() < new Date(auction.starts_at) ? (
                  <Badge className="bg-[#f3f3f3] text-[#75787c] border border-[#dedfe0]">
                    Not Started
                  </Badge>
                ) : auction.winner_vendor_email ? (
                  <Badge className="bg-[#00573d] text-white border-0">
                    Awarded
                  </Badge>
                ) : new Date() > new Date(auction.ends_at) ? (
                  <Badge className="bg-[#9fa1a4] text-white border-0">
                    Ended
                  </Badge>
                ) : (
                  <Badge className="bg-[#004b8d] text-white border-0">
                    Active
                  </Badge>
                )}
              </div>
              <CardTitle className="text-2xl">{auction.title}</CardTitle>
              <CardDescription className="mt-2">{auction.description}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Auto-populated info */}
          {(auction.date_requested || auction.requestor || auction.group_site || auction.event_type) && (
            <div className="mb-4 p-3 bg-[#f3f3f3] rounded-md border border-[#dedfe0]">
              <h4 className="text-sm font-semibold text-[#262728] mb-2">Request Information</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                {auction.date_requested && (
                  <div>
                    <span className="text-[#626467]">Date Requested:</span>
                    <div className="font-medium text-[#262728]">{auction.date_requested}</div>
                  </div>
                )}
                {auction.requestor && (
                  <div>
                    <span className="text-[#626467]">Requestor:</span>
                    <div className="font-medium text-[#262728]">{auction.requestor}</div>
                  </div>
                )}
                {auction.group_site && (
                  <div>
                    <span className="text-[#626467]">Group/Site:</span>
                    <div className="font-medium text-[#262728]">{auction.group_site}</div>
                  </div>
                )}
                {auction.event_type && (
                  <div>
                    <span className="text-[#626467]">Event Type:</span>
                    <div className="font-medium text-[#262728]">
                      {auction.event_type === 'ORDER' ? '🔒 ORDER' : '📄 QUOTE'}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            {auction.target_lead_time && (
              <div>
                <span className="text-[#626467]">Target Lead Time:</span>
                <div className="font-semibold text-[#00573d]">{auction.target_lead_time} days (ARO)</div>
              </div>
            )}
            {auction.quantity && (
              <div>
                <span className="text-[#626467]">Part Numbers & Qty:</span>
                <div className="font-semibold text-[#262728]">{auction.quantity}</div>
              </div>
            )}
            {auction.delivery_location && (
              <div>
                <span className="text-[#626467]">Location:</span>
                <div className="font-semibold text-[#262728]">{auction.delivery_location}</div>
              </div>
            )}
            <div>
              <span className="text-[#626467]">Starts:</span>
              <div className="font-semibold text-[#262728]">
                {new Date(auction.starts_at).toLocaleString()}
              </div>
            </div>
            <div>
              <span className="text-[#626467]">Ends:</span>
              <div className="font-semibold text-[#262728]">
                {new Date(auction.ends_at).toLocaleString()}
              </div>
            </div>
          </div>
          {auction.notes && (
            <div className="mt-4 p-3 bg-[#f3f3f3] rounded-md border border-[#dedfe0]">
              <span className="text-sm text-[#626467] font-medium">Notes:</span>
              <div className="text-sm mt-1 text-[#262728]">{auction.notes}</div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Invited Vendors */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Invited Vendors ({invites.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Email</TableHead>
                <TableHead>Invite Code</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invites.map((invite, index) => (
                <TableRow key={invite.id}>
                  <TableCell className="font-medium">{invite.email}</TableCell>
                  <TableCell className="font-mono text-sm">{invite.invite_code}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        invite.status === 'accessed' ? 'default' : 'secondary'
                      }
                    >
                      {invite.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyCode(invite.invite_code)}
                    >
                      <Copy className="h-3 w-3 mr-1" />
                      Code
                    </Button>
                    <Button
                      size="sm"
                      variant="default"
                      onClick={() => copyInvite(index)}
                    >
                      {copiedIndex === index ? (
                        <Check className="h-3 w-3 mr-1" />
                      ) : (
                        <Copy className="h-3 w-3 mr-1" />
                      )}
                      Full Invite
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Bids Table / Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle>Bids & Leaderboard ({bids.length})</CardTitle>
          <CardDescription>Sorted by delivery time (ASC), then price (ASC)</CardDescription>
        </CardHeader>
        <CardContent>
          {bids.length === 0 ? (
            <div className="text-center py-8 text-gray-500">No bids yet</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">Rank</TableHead>
                  <TableHead>Company</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Delivery Time (days)</TableHead>
                  <TableHead>Price ($)</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bids.map((bid, index) => (
                  <TableRow
                    key={bid.id}
                    className={index === 0 ? 'bg-[#f3f3f3] border-l-4 border-l-[#00573d]' : ''}
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {index === 0 && <Crown className="h-4 w-4 text-yellow-500" />}
                        <span className="font-bold">#{index + 1}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{bid.company_name || '-'}</TableCell>
                    <TableCell>{bid.contact_name || '-'}</TableCell>
                    <TableCell>{bid.vendor_email}</TableCell>
                    <TableCell className="font-semibold text-blue-600">
                      {bid.delivery_time}
                    </TableCell>
                    <TableCell className="font-semibold text-green-600">
                      ${bid.price.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {new Date(bid.updated_at).toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right">
                      {index === 0 && auction.status === 'active' && !auction.winner_vendor_email && (
                        <Button
                          size="sm"
                          onClick={() => selectWinner(bid.vendor_email)}
                        >
                          <Crown className="h-3 w-3 mr-1" />
                          Select Winner
                        </Button>
                      )}
                      {auction.winner_vendor_email === bid.vendor_email && (
                        <Badge variant="default">
                          <Crown className="h-3 w-3 mr-1" />
                          Winner
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}