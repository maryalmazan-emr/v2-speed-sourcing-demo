import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { AlertCircle, RefreshCw, Server } from 'lucide-react';

interface ServerStatusErrorProps {
  onRetry: () => void;
}

export function ServerStatusError({ onRetry }: ServerStatusErrorProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="max-w-lg w-full">
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <CardTitle>Backend Server Not Available</CardTitle>
              <CardDescription className="mt-1">
                The Edge Function is not responding
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex gap-3">
              <Server className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-yellow-800">
                <p className="font-medium mb-1">Deployment Required</p>
                <p className="text-yellow-700">
                  The Supabase Edge Function needs to be deployed before the application can function.
                  This typically happens automatically in Figma Make.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-medium text-sm">Troubleshooting Steps:</h3>
            <ol className="text-sm text-gray-600 space-y-2 list-decimal list-inside">
              <li>Wait a few moments for automatic deployment</li>
              <li>Click the retry button below</li>
              <li>Check the browser console for detailed error messages</li>
              <li>Verify the Supabase project is properly configured</li>
            </ol>
          </div>

          <div className="pt-2 space-y-2">
            <Button onClick={onRetry} className="w-full" size="lg">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry Connection
            </Button>
            
            <p className="text-xs text-gray-500 text-center">
              If the issue persists, please contact support or check the deployment logs.
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-3 text-xs text-gray-600">
            <p className="font-medium mb-1">Technical Details:</p>
            <ul className="space-y-1">
              <li>• Edge Function Path: /make-server-923810f5/*</li>
              <li>• Expected Response: JSON with CORS headers</li>
              <li>• Current Status: Connection failed or non-JSON response</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
