import React, { useState, useEffect } from 'react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { ArrowLeft, Copy, Search, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { apiCall } from '@/lib/api';
import { copyToClipboard } from '@/lib/clipboard';
import { hasGlobalAccess, canDelete, getRoleName } from '@/lib/adminAuth';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/app/components/ui/table';

interface AccountsProps {
  onBack: () => void;
  adminEmail: string;
  userRole: 'owner' | 'global_admin' | 'internal_user';
}

export function Accounts({ onBack, adminEmail, userRole }: AccountsProps) {
  const hasGlobalView = hasGlobalAccess(userRole);
  const canDeleteAccounts = canDelete(userRole);
  const [invites, setInvites] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadInvites();
  }, []);

  const loadInvites = async () => {
    try {
      const res = await apiCall('/make-server-923810f5/invites');
      const data = await res.json();
      
      // Filter invites based on role
      let filteredInvites = data.invites || [];
      
      if (!hasGlobalView) {
        // Regular internal users only see invites from their own auctions
        // Get all auctions created by this user
        const auctionsRes = await apiCall('/make-server-923810f5/auctions');
        const auctionsData = await auctionsRes.json();
        const myAuctionIds = (auctionsData.auctions || [])
          .filter((auction: any) => auction.requestor_email === adminEmail)
          .map((auction: any) => auction.id);
        
        // Filter invites to only those from my auctions
        filteredInvites = filteredInvites.filter((invite: any) => 
          myAuctionIds.includes(invite.auction_id)
        );
      }
      
      setInvites(filteredInvites);
    } catch (error) {
      console.error('Error loading invites:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async (inviteId: string, email: string, e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!canDeleteAccounts) {
      toast.error('Only the Owner can delete accounts');
      return;
    }

    const confirmed = window.confirm(
      `Are you sure you want to permanently delete this account?\n\nExternal Guest: ${email}\n\nThis action cannot be undone.`
    );

    if (!confirmed) return;

    try {
      const res = await apiCall(`/make-server-923810f5/invites/${inviteId}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        throw new Error('Failed to delete account');
      }

      toast.success('Account deleted successfully');
      loadInvites(); // Reload the list
    } catch (error) {
      console.error('Error deleting account:', error);
      toast.error('Failed to delete account');
    }
  };

  const copyCode = async (code: string) => {
    const success = await copyToClipboard(code);
    if (success) {
      toast.success('Code copied');
    } else {
      toast.error('Failed to copy to clipboard');
    }
  };

  const copyInvite = async (invite: any) => {
    const message = `You're invited to Reverse Auction: ${invite.auction_title}

Portal URL: ${window.location.origin}
Email: ${invite.email}
Invite Code: ${invite.invite_code}

Please log in to submit your bid.`;

    const success = await copyToClipboard(message);
    if (success) {
      toast.success('Invite copied to clipboard');
    } else {
      toast.error('Failed to copy to clipboard');
    }
  };

  const getFilteredInvites = () => {
    if (!searchTerm) return invites;
    
    const term = searchTerm.toLowerCase();
    return invites.filter(invite =>
      invite.email.toLowerCase().includes(term) ||
      invite.invite_code.toLowerCase().includes(term) ||
      invite.auction_title.toLowerCase().includes(term)
    );
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">Loading accounts...</div>
      </div>
    );
  }

  const filteredInvites = getFilteredInvites();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button variant="outline" onClick={onBack} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <h1 className="text-3xl font-bold">Accounts</h1>
        <p className="text-gray-600 mt-1">
          {hasGlobalView 
            ? `🔑 ${getRoleName(userRole)} - Viewing ALL External Guest accounts from all auctions` 
            : `External Guest accounts you've invited (${adminEmail})`}
        </p>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search by email, code, or auction..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Accounts Table */}
      <Card>
        <CardHeader>
          <CardTitle>External Guest Accounts ({filteredInvites.length})</CardTitle>
          <CardDescription>
            All External Guest invitations and access codes
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredInvites.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              No accounts found
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Invite Code</TableHead>
                  <TableHead>Auction</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Accessed</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInvites.map((invite) => (
                  <TableRow key={invite.id}>
                    <TableCell className="font-medium">{invite.email}</TableCell>
                    <TableCell className="font-mono text-sm">{invite.invite_code}</TableCell>
                    <TableCell className="max-w-xs truncate">{invite.auction_title}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          invite.status === 'accessed' ? 'default' :
                          invite.status === 'sent' ? 'secondary' :
                          'outline'
                        }
                      >
                        {invite.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {invite.accessed_at
                        ? new Date(invite.accessed_at).toLocaleString()
                        : '-'}
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyCode(invite.invite_code)}
                      >
                        <Copy className="h-3 w-3 mr-1" />
                        Code
                      </Button>
                      <Button
                        size="sm"
                        variant="default"
                        onClick={() => copyInvite(invite)}
                      >
                        <Copy className="h-3 w-3 mr-1" />
                        Full Invite
                      </Button>
                      {canDeleteAccounts && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          onClick={(e) => handleDeleteAccount(invite.id, invite.email, e)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}