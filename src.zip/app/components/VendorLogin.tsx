import React, { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { toast } from 'sonner';
import { apiCall } from '@/lib/api';

interface VendorLoginProps {
  onLogin: (session: any, auctionId: string) => void;
}

export function VendorLogin({ onLogin }: VendorLoginProps) {
  const [email, setEmail] = useState('');
  const [inviteCode, setInviteCode] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      console.log('Attempting login with:', { email, invite_code: inviteCode });
      
      const res = await apiCall(
        '/make-server-923810f5/vendor/login',
        {
          method: 'POST',
          body: JSON.stringify({ email, invite_code: inviteCode })
        }
      );

      if (!res.ok) {
        const error = await res.json();
        console.error('Login failed:', error);
        toast.error(error.error || 'Invalid email or invite code');
        throw new Error(error.error || 'Login failed');
      }

      const data = await res.json();
      console.log('Login successful:', data);
      toast.success('Login successful!');
      onLogin(data.session, data.auction_id);
    } catch (error: any) {
      console.error('Login error:', error);
      // Error already shown above
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">External Guest Login</CardTitle>
          <CardDescription>
            Enter your email and invite code to access the auction
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="guest@company.com"
                required
              />
            </div>
            <div>
              <Label htmlFor="invite-code">Invite Code</Label>
              <Input
                id="invite-code"
                value={inviteCode}
                onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                placeholder="ABC123XYZ"
                required
                className="font-mono"
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? 'Logging in...' : 'Login'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}