import React, { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Textarea } from '@/app/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Copy, Check, ArrowRight, ArrowLeft, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { apiCall } from '@/lib/api';
import { copyToClipboard } from '@/lib/clipboard';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/app/components/ui/select';

interface PartNumber {
  id: string;
  part_number: string;
  quantity: string;
}

interface AdminSetupProps {
  onComplete: () => void;
  adminSession: any;
}

export function AdminSetup({ onComplete, adminSession }: AdminSetupProps) {
  const [step, setStep] = useState(1);
  
  // Basic Info
  const [formData, setFormData] = useState({
    date_requested: new Date().toISOString().split('T')[0],
    requestor: adminSession.name || 'Current User',
    requestor_email: adminSession.email || 'admin@emerson.com',
    group_site: '',
    name: '',
    description: '',
    start_date: '',
    end_date: '',
    event_type: '',
    target_lead_time: '',
    notes: ''
  });

  // Part Numbers & Quantities
  const [partNumbers, setPartNumbers] = useState<PartNumber[]>([
    { id: '1', part_number: '', quantity: '' }
  ]);

  // External Guest emails (simplified - just paste emails)
  const [vendorEmails, setVendorEmails] = useState('');

  const [invites, setInvites] = useState<any[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  const addPartNumber = () => {
    setPartNumbers([
      ...partNumbers,
      { id: Date.now().toString(), part_number: '', quantity: '' }
    ]);
  };

  const removePartNumber = (id: string) => {
    if (partNumbers.length > 1) {
      setPartNumbers(partNumbers.filter(p => p.id !== id));
    }
  };

  const updatePartNumber = (id: string, field: 'part_number' | 'quantity', value: string) => {
    setPartNumbers(partNumbers.map(p =>
      p.id === id ? { ...p, [field]: value } : p
    ));
  };

  const handleNext = () => {
    if (step === 1) {
      if (!formData.group_site || !formData.name || !formData.description) {
        toast.error('Group/Site, Name, and Description are required');
        return;
      }
      if (!formData.start_date || !formData.end_date) {
        toast.error('Start and End dates are required');
        return;
      }
      if (!formData.event_type) {
        toast.error('Event Type is required');
        return;
      }
      if (!formData.target_lead_time) {
        toast.error('Target Lead Time is required');
        return;
      }
      const startDate = new Date(formData.start_date);
      const endDate = new Date(formData.end_date);
      if (endDate <= startDate) {
        toast.error('End date must be after start date');
        return;
      }
      
      // Check part numbers
      const validParts = partNumbers.filter(p => p.part_number && p.quantity);
      if (validParts.length === 0) {
        toast.error('At least one part number with quantity is required');
        return;
      }
    }
    
    if (step === 2) {
      // Parse External Guest emails
      const emails = vendorEmails
        .split(/[,\n]/)
        .map(e => e.trim())
        .filter(e => e && e.includes('@'));
      
      if (emails.length === 0) {
        toast.error('Please enter at least one valid email address');
        return;
      }
      
      generateInvites(emails);
      return;
    }
    
    setStep(step + 1);
  };

  const handleBack = () => {
    setStep(step - 1);
  };

  const generateInvites = (emails: string[]) => {
    const generated = emails.map(email => ({
      email,
      invite_code: generateCode(),
      status: 'pending'
    }));

    setInvites(generated);
    setStep(3);
  };

  const generateCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 10; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  const copyInvite = async (index: number) => {
    const invite = invites[index];
    const validParts = partNumbers.filter(p => p.part_number && p.quantity);
    const partsText = validParts.map(p => `${p.part_number} - Qty: ${p.quantity}`).join('\n');
    
    const eventTypeText = formData.event_type === 'ORDER' 
      ? 'ORDER - Firm commitment to purchase' 
      : 'QUOTE - Request for quotation only';
    
    const message = `EMERSON REVERSE AUCTION INVITATION

Event ID: [Auto-generated after submission]
Requestor: ${formData.requestor}
End Date: ${new Date(formData.end_date).toLocaleString()}
Target Lead Time (ARO): ${formData.target_lead_time} days

Event Type: ${eventTypeText}

Part Numbers & Quantities:
${partsText}

You are invited to participate in this reverse auction event. Please submit your most competitive bid for the items listed above.

Portal URL: ${window.location.origin}
Your Email: ${invite.email}
Invite Code: ${invite.invite_code}

${formData.event_type === 'ORDER' 
  ? 'This is a firm order request. By submitting a bid, you are committing to fulfill the order at the quoted price and delivery time if selected as the winner.' 
  : 'This is a request for quotation. Winning bid will receive a formal purchase order for final review and acceptance.'}

Best regards,
${formData.requestor}
Emerson Speed Sourcing Team`;

    const success = await copyToClipboard(message);
    if (success) {
      setCopiedIndex(index);
      toast.success('Invitation copied to clipboard');
      setTimeout(() => setCopiedIndex(null), 2000);
    } else {
      toast.error('Failed to copy to clipboard');
    }
  };

  const handleSaveDraft = async () => {
    await launchAuction('draft');
  };

  const handleSubmit = async () => {
    await launchAuction('active');
  };

  const launchAuction = async (status: 'draft' | 'active') => {
    if (loading) return; // Prevent double submission
    
    setLoading(true);
    try {
      const validParts = partNumbers.filter(p => p.part_number && p.quantity);
      
      // Create auction
      const auctionRes = await apiCall(
        '/make-server-923810f5/auctions',
        {
          method: 'POST',
          body: JSON.stringify({
            title: formData.name,
            description: formData.description,
            quantity: validParts.map(p => `${p.part_number}: ${p.quantity}`).join('; '),
            delivery_location: '',
            notes: formData.notes,
            starts_at: new Date(formData.start_date).toISOString(),
            ends_at: new Date(formData.end_date).toISOString(),
            status: status,
            date_requested: formData.date_requested,
            requestor: formData.requestor,
            requestor_email: formData.requestor_email,
            group_site: formData.group_site,
            event_type: formData.event_type,
            target_lead_time: formData.target_lead_time,
            part_numbers: JSON.stringify(validParts)
          })
        }
      );

      if (!auctionRes.ok) {
        const errorData = await auctionRes.json();
        throw new Error(errorData.error || 'Failed to create auction');
      }
      const auctionData = await auctionRes.json();

      // Create invites
      const inviteRes = await apiCall(
        `/make-server-923810f5/auctions/${auctionData.auction.id}/invites`,
        {
          method: 'POST',
          body: JSON.stringify({
            invites: invites.map(i => ({
              email: i.email,
              invite_code: i.invite_code
            })),
            mode: 'prototype'
          })
        }
      );

      if (!inviteRes.ok) {
        const errorData = await inviteRes.json();
        throw new Error(errorData.error || 'Failed to create invites');
      }

      toast.success(status === 'draft' 
        ? `Draft saved with ${invites.length} External Guest invitations!` 
        : `Auction launched with ${invites.length} External Guest invitations!`
      );
      
      onComplete();
    } catch (error) {
      console.error('Launch error:', error);
      toast.error('Failed to ' + (status === 'draft' ? 'save draft' : 'launch auction') + ': ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl" style={{ maxWidth: '1180px' }}>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 text-[#262728]">New Auction Request</h1>
        <div className="flex gap-2">
          {[1, 2, 3].map(s => (
            <div
              key={s}
              className={`flex-1 h-2 rounded ${
                s <= step ? 'bg-[#00573d]' : 'bg-[#dedfe0]'
              }`}
            />
          ))}
        </div>
      </div>

      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Step 1: Basic Info & Event Details</CardTitle>
            <CardDescription>Define the auction parameters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Auto-populated fields */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-[#f3f3f3] rounded-md border border-[#dedfe0]">
              <div>
                <Label className="text-xs text-[#626467]">Date Requested</Label>
                <div className="font-medium text-[#262728]">{formData.date_requested}</div>
              </div>
              <div>
                <Label className="text-xs text-[#626467]">Requestor</Label>
                <div className="font-medium text-[#262728]">{formData.requestor}</div>
              </div>
              <div>
                <Label className="text-xs text-[#626467]">Requestor Email</Label>
                <div className="font-medium text-[#262728]">{formData.requestor_email}</div>
              </div>
            </div>

            {/* Group/Site */}
            <div>
              <Label htmlFor="group_site">Group/Site *</Label>
              <Select value={formData.group_site} onValueChange={(value) => setFormData({ ...formData, group_site: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select group/site" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MTN">MTN – Marshalltown, IA</SelectItem>
                  <SelectItem value="MTWN">MTWN – Marshalltown, IA</SelectItem>
                  <SelectItem value="SMR">SMR – Summer, WA</SelectItem>
                  <SelectItem value="RRC">RRC – Rochester, NY</SelectItem>
                  <SelectItem value="STL">STL – St. Louis, MO</SelectItem>
                  <SelectItem value="BOUL">BOUL – Boulder, CO</SelectItem>
                  <SelectItem value="SJO">SJO – San Jose, CA</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Name */}
            <div>
              <Label htmlFor="name">Name (Title of this event) *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Industrial Safety Equipment Q1 2026"
              />
            </div>

            {/* Description */}
            <div>
              <Label htmlFor="description">Description (Details of this event) *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Detailed requirements, specifications, and expectations..."
                rows={4}
              />
            </div>

            {/* Event Type */}
            <div>
              <Label htmlFor="event_type">Event Type *</Label>
              <Select value={formData.event_type} onValueChange={(value) => setFormData({ ...formData, event_type: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select event type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ORDER">ORDER - Firm commitment to purchase</SelectItem>
                  <SelectItem value="QUOTE">QUOTE - Request for quotation</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Dates */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start_date">Start Date *</Label>
                <Input
                  id="start_date"
                  type="datetime-local"
                  value={formData.start_date}
                  onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="end_date">End Date *</Label>
                <Input
                  id="end_date"
                  type="datetime-local"
                  value={formData.end_date}
                  onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                />
              </div>
            </div>

            {/* Target Lead Time */}
            <div>
              <Label htmlFor="target_lead_time">Target Lead Time (ARO - After Receipt of Order) *</Label>
              <div className="flex gap-2 items-center">
                <Input
                  id="target_lead_time"
                  type="number"
                  value={formData.target_lead_time}
                  onChange={(e) => setFormData({ ...formData, target_lead_time: e.target.value })}
                  placeholder="e.g., 30"
                  className="max-w-xs"
                />
                <span className="text-sm text-[#626467]">days</span>
              </div>
            </div>

            {/* Part Numbers & Quantities */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label>Part Numbers & Quantities *</Label>
                <Button size="sm" variant="outline" onClick={addPartNumber}>
                  <Plus className="h-4 w-4 mr-1" />
                  Add Part
                </Button>
              </div>
              <div className="space-y-2">
                {partNumbers.map((part) => (
                  <div key={part.id} className="flex gap-2 items-center">
                    <Input
                      placeholder="Part Number"
                      value={part.part_number}
                      onChange={(e) => updatePartNumber(part.id, 'part_number', e.target.value)}
                      className="flex-1"
                    />
                    <Input
                      placeholder="Quantity"
                      value={part.quantity}
                      onChange={(e) => updatePartNumber(part.id, 'quantity', e.target.value)}
                      className="w-32"
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => removePartNumber(part.id)}
                      disabled={partNumbers.length === 1}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            {/* Notes */}
            <div>
              <Label htmlFor="notes">Additional Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Any additional information..."
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      )}

      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle>Step 2: External Guest Emails</CardTitle>
            <CardDescription>Paste External Guest email addresses (one per line or comma-separated). External Guests will provide their company info when they log in.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="vendor_emails">External Guest Email Addresses *</Label>
              <Textarea
                id="vendor_emails"
                value={vendorEmails}
                onChange={(e) => setVendorEmails(e.target.value)}
                placeholder="guest1@company.com&#10;guest2@company.com&#10;guest3@company.com&#10;&#10;Or comma-separated: guest1@company.com, guest2@company.com"
                rows={10}
                className="font-mono text-sm"
              />
              <p className="text-xs text-[#626467] mt-2">
                Tip: Paste one email per line, or separate with commas. External Guests will enter their company name and contact details when they log in to place their bid.
              </p>
            </div>
            
            {vendorEmails.trim() && (
              <div className="p-3 bg-[#f3f3f3] rounded-md border border-[#dedfe0]">
                <p className="text-sm text-[#626467]">
                  <strong>Preview:</strong> {vendorEmails.split(/[,\n]/).filter(e => e.trim() && e.includes('@')).length} valid email(s) detected
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {step === 3 && (
        <Card>
          <CardHeader>
            <CardTitle>Step 3: Review & Launch</CardTitle>
            <CardDescription>Review invitation details and launch the auction</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-[#f3f3f3] rounded-md border border-[#dedfe0]">
              <h3 className="font-semibold mb-2 text-[#262728]">Auction Summary</h3>
              <div className="space-y-1 text-sm">
                <div><span className="text-[#626467]">Name:</span> <span className="font-medium">{formData.name}</span></div>
                <div><span className="text-[#626467]">Group/Site:</span> <span className="font-medium">{formData.group_site}</span></div>
                <div><span className="text-[#626467]">Event Type:</span> <span className="font-medium">{formData.event_type}</span></div>
                <div><span className="text-[#626467]">Target Lead Time:</span> <span className="font-medium">{formData.target_lead_time} days</span></div>
                <div><span className="text-[#626467]">Duration:</span> <span className="font-medium">{new Date(formData.start_date).toLocaleString()} → {new Date(formData.end_date).toLocaleString()}</span></div>
                <div><span className="text-[#626467]">Vendors:</span> <span className="font-medium">{invites.length}</span></div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3 text-[#262728]">Vendor Invitations</h3>
              <div className="space-y-2">
                {invites.map((invite, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-white border border-[#dedfe0] rounded-md">
                    <div className="flex-1">
                      <div className="font-medium text-[#262728]">{invite.email}</div>
                      <div className="text-xs text-[#9fa1a4] font-mono mt-1">Code: {invite.invite_code}</div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyInvite(index)}
                    >
                      {copiedIndex === index ? (
                        <Check className="h-3 w-3 mr-1" />
                      ) : (
                        <Copy className="h-3 w-3 mr-1" />
                      )}
                      Copy Invite
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 bg-[#004b8d]/10 border border-[#004b8d]/20 rounded-md">
              <p className="text-sm text-[#262728]">
                <strong>Note:</strong> Invitation emails include Event ID, Requestor, End Date, Target Lead Time, Part Numbers & Quantities, and link to the live auction.
                {formData.event_type === 'ORDER' && ' This is a firm ORDER - winning bid will be binding.'}
                {formData.event_type === 'QUOTE' && ' This is a QUOTE request - winning bid will receive PO for review.'}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Navigation */}
      <div className="flex items-center justify-between mt-6">
        <div>
          {step > 1 && (
            <Button variant="outline" onClick={handleBack} disabled={loading}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
          )}
        </div>
        <div className="flex gap-2">
          {step === 3 && (
            <Button variant="outline" onClick={handleSaveDraft} disabled={loading}>
              Save as Draft
            </Button>
          )}
          <Button onClick={step === 3 ? handleSubmit : handleNext} disabled={loading}>
            {loading ? 'Processing...' : step === 3 ? 'Submit & Launch' : 'Next'}
            {step < 3 && <ArrowRight className="h-4 w-4 ml-2" />}
          </Button>
        </div>
      </div>
    </div>
  );
}