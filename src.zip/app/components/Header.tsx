import React, { useState, useEffect } from 'react';
import { Button } from '@/app/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/app/components/ui/dropdown-menu';
import { Menu, RotateCcw } from 'lucide-react';
import emersonLogo from 'figma:asset/cfb5256627e7fcdeba54c066caa0f735f3024eb6.png';

interface HeaderProps {
  auction: any | null;
  role: 'admin' | 'vendor';
  onRoleChange: (role: 'admin' | 'vendor') => void;
  onNavigate: (view: string) => void;
  onResetAuction?: () => void;
  onCreateAuction?: () => void;
  onAdminLogout?: () => void;
  currentUser?: string;
}

export function Header({ auction, role, onRoleChange, onNavigate, onResetAuction, onCreateAuction, onAdminLogout, currentUser }: HeaderProps) {
  const [timeLeft, setTimeLeft] = useState<string>('');
  const [isWarning, setIsWarning] = useState(false);

  useEffect(() => {
    if (!auction || !auction.ends_at) {
      setTimeLeft('');
      return;
    }

    // If auction is closed (has a winner), stop the timer
    if (auction.winner_vendor_email) {
      setTimeLeft('Winner selected');
      setIsWarning(false);
      return;
    }

    const updateTimer = () => {
      const now = new Date().getTime();
      const start = new Date(auction.starts_at).getTime();
      const end = new Date(auction.ends_at).getTime();

      // If auction hasn't started yet
      if (now < start) {
        setTimeLeft('Auction not started');
        setIsWarning(false);
        return;
      }

      const diff = end - now;

      if (diff <= 0) {
        setTimeLeft('Auction ended');
        setIsWarning(false);
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      const totalHours = days * 24 + hours;
      setIsWarning(totalHours < 1);

      if (days > 0) {
        setTimeLeft(`${days}d ${hours.toString().padStart(2, '0')}h ${minutes.toString().padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`);
      } else {
        setTimeLeft(`${hours.toString().padStart(2, '0')}h ${minutes.toString().padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [auction]);

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between" style={{ maxWidth: '1180px' }}>
        {/* Left: Logo */}
        <div className="flex items-center gap-4">
          <img 
            src={emersonLogo} 
            alt="Emerson Logo" 
            className="h-10 w-auto object-contain"
          />
          <span className="font-semibold text-lg text-[#262728] hidden md:inline">Speed Sourcing Portal</span>
        </div>

        {/* Center: Countdown Timer */}
        <div className="flex-1 flex justify-center">
          {timeLeft && (
            <div
              className={`px-6 py-2 rounded-md font-mono text-base font-semibold ${ timeLeft === 'Winner selected' 
                  ? 'bg-[#00573d] text-white'
                  : timeLeft === 'Auction ended'
                  ? 'bg-[#dedfe0] text-[#626467]'
                  : timeLeft === 'Auction not started'
                  ? 'bg-[#f3f3f3] text-[#75787c] border border-[#dedfe0]'
                  : isWarning
                  ? 'bg-[#d4183d] text-white animate-pulse'
                  : 'bg-[#004b8d] text-white'
              }`}
            >
              {timeLeft === 'Winner selected' ? '🏆 Winner Selected' 
                : timeLeft === 'Auction ended' ? '⏱️ Auction Ended'
                : timeLeft === 'Auction not started' ? '⏸️ Auction Not Started'
                : `Time left: ${timeLeft}`}
            </div>
          )}
          {!timeLeft && auction && (
            <div className="text-[#9fa1a4] text-sm">No active auction</div>
          )}
        </div>

        {/* Right: Navigation Menu */}
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="border-[#c9cacc] text-[#262728] hover:bg-[#f3f3f3]">
                <Menu className="h-4 w-4 mr-2" />
                Menu
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onClick={() => onRoleChange('admin')}>
                🛡️ Admin (Buyer) View
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onRoleChange('vendor')}>
                🏢 Vendor View
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => onNavigate('all-auctions')}>
                📋 All Auctions
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onNavigate('accounts')}>
                👥 Accounts
              </DropdownMenuItem>
              {onResetAuction && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onResetAuction}>
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Close Current Auction
                  </DropdownMenuItem>
                </>
              )}
              {onCreateAuction && (
                <>
                  <DropdownMenuItem onClick={onCreateAuction}>
                    🆕 Create New Auction
                  </DropdownMenuItem>
                </>
              )}
              {onAdminLogout && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onAdminLogout}>
                    Logout
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
          <div className="text-xs font-medium text-white px-3 py-1 bg-[#00573d] rounded-md">
            {role === 'admin' ? 'Internal User' : 'External Guest'}
          </div>
          {currentUser && (
            <div className="text-xs font-medium text-gray-500 px-3 py-1 bg-gray-100 rounded-md">
              {currentUser}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}