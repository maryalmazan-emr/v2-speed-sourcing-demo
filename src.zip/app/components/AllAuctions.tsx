import React, { useState, useEffect } from 'react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { ArrowLeft, Crown, Search, Trash2 } from 'lucide-react';
import { apiCall } from '@/lib/api';
import { hasGlobalAccess, canDelete, getRoleName } from '@/lib/adminAuth';
import { toast } from 'sonner';

interface AllAuctionsProps {
  onBack: () => void;
  onSelectAuction: (auction: any) => void;
  adminEmail: string;
  adminPassword: string;
  userRole: 'owner' | 'global_admin' | 'internal_user';
}

export function AllAuctions({ onBack, onSelectAuction, adminEmail, adminPassword, userRole }: AllAuctionsProps) {
  const hasGlobalView = hasGlobalAccess(userRole);
  const canDeleteAuctions = canDelete(userRole);
  const [auctions, setAuctions] = useState<any[]>([]);
  const [filter, setFilter] = useState<'all' | 'active' | 'closed' | 'awarded'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAuctions();
  }, []);

  const loadAuctions = async () => {
    try {
      const res = await apiCall('/make-server-923810f5/auctions');
      const data = await res.json();
      
      // Filter auctions based on role
      const myAuctions = (data.auctions || []).filter((auction: any) => 
        hasGlobalView || auction.requestor_email === adminEmail
      );
      
      setAuctions(myAuctions);
    } catch (error) {
      console.error('Error loading auctions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAuction = async (auctionId: string, auctionTitle: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card click
    
    if (!canDeleteAuctions) {
      toast.error('Only the Owner can delete auctions');
      return;
    }

    const confirmed = window.confirm(
      `Are you sure you want to permanently delete this auction?\n\n"${auctionTitle}"\n\nThis action cannot be undone and will remove all associated data.`
    );

    if (!confirmed) return;

    try {
      const res = await apiCall(`/make-server-923810f5/auctions/${auctionId}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        throw new Error('Failed to delete auction');
      }

      toast.success('Auction deleted successfully');
      loadAuctions(); // Reload the list
    } catch (error) {
      console.error('Error deleting auction:', error);
      toast.error('Failed to delete auction');
    }
  };

  // Generate a readable short ID from the UUID
  const getShortId = (uuid: string) => {
    // Take first 8 characters and uppercase
    return uuid.substring(0, 8).toUpperCase();
  };

  const getStatusBadge = (auction: any) => {
    const now = new Date();
    const endsAt = new Date(auction.ends_at);
    
    if (auction.winner_vendor_email) {
      return <Badge className="bg-[#00573d] text-white border-0">Awarded</Badge>;
    } else if (auction.status === 'manually_closed') {
      return <Badge className="bg-[#9fa1a4] text-white border-0">Closed</Badge>;
    } else if (endsAt < now) {
      return <Badge className="bg-[#9fa1a4] text-white border-0">Closed</Badge>;
    } else {
      return <Badge className="bg-[#004b8d] text-white border-0">Active</Badge>;
    }
  };

  const getFilteredAuctions = () => {
    const now = new Date();
    
    return auctions.filter(auction => {
      // Apply status filter
      if (filter === 'awarded' && !auction.winner_vendor_email) return false;
      if (filter === 'closed' && !(auction.status === 'manually_closed' || (new Date(auction.ends_at) < now && !auction.winner_vendor_email))) return false;
      if (filter === 'active' && (auction.status === 'manually_closed' || new Date(auction.ends_at) < now || auction.winner_vendor_email)) return false;
      
      // Apply search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const shortId = getShortId(auction.id).toLowerCase();
        const fullId = auction.id.toLowerCase();
        const title = auction.title?.toLowerCase() || '';
        const description = auction.description?.toLowerCase() || '';
        const groupSite = auction.group_site?.toLowerCase() || '';
        const requestor = auction.requestor?.toLowerCase() || '';
        
        return (
          shortId.includes(query) ||
          fullId.includes(query) ||
          title.includes(query) ||
          description.includes(query) ||
          groupSite.includes(query) ||
          requestor.includes(query)
        );
      }
      
      return true;
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">Loading auctions...</div>
      </div>
    );
  }

  const filteredAuctions = getFilteredAuctions();

  return (
    <div className="container mx-auto px-4 py-8" style={{ maxWidth: '1180px' }}>
      <div className="mb-6">
        <Button variant="outline" onClick={onBack} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <h1 className="text-3xl font-bold text-[#262728]">All Auctions</h1>
        <p className="text-[#626467] mt-1">
          {hasGlobalView 
            ? `🔑 ${getRoleName(userRole)} - Viewing ALL auctions from all users` 
            : `Showing auctions created by ${adminEmail}`}
        </p>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-[#9fa1a4]" />
          <Input
            placeholder="Search by ID, name, description, site, requestor..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        {searchQuery && (
          <div className="text-sm text-[#626467] mt-2">
            Found {filteredAuctions.length} result{filteredAuctions.length !== 1 ? 's' : ''}
          </div>
        )}
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-6">
        <Button
          variant={filter === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('all')}
        >
          All ({auctions.length})
        </Button>
        <Button
          variant={filter === 'active' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('active')}
        >
          Active
        </Button>
        <Button
          variant={filter === 'closed' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('closed')}
        >
          Closed
        </Button>
        <Button
          variant={filter === 'awarded' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('awarded')}
        >
          Awarded
        </Button>
      </div>

      {/* Auctions List */}
      {filteredAuctions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-gray-500">
            {searchQuery ? 'No auctions match your search' : 'No auctions found'}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredAuctions.map((auction) => (
            <Card key={auction.id} className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => onSelectAuction(auction)}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-mono text-[#9fa1a4] bg-[#f3f3f3] px-2 py-1 rounded">
                        ID: {getShortId(auction.id)}
                      </span>
                      {auction.group_site && (
                        <span className="text-xs text-[#626467] bg-[#f3f3f3] px-2 py-1 rounded">
                          {auction.group_site}
                        </span>
                      )}
                    </div>
                    <CardTitle className="text-xl">{auction.title}</CardTitle>
                    <CardDescription className="mt-2 line-clamp-2">
                      {auction.description}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(auction)}
                    {canDeleteAuctions && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={(e) => handleDeleteAuction(auction.id, auction.title, e)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  {auction.requestor && (
                    <div>
                      <span className="text-gray-600">Requestor:</span>
                      <div className="font-medium">{auction.requestor}</div>
                    </div>
                  )}
                  <div>
                    <span className="text-gray-600">Started:</span>
                    <div className="font-medium">
                      {new Date(auction.starts_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-600">Ends:</span>
                    <div className="font-medium">
                      {new Date(auction.ends_at).toLocaleDateString()}
                    </div>
                  </div>
                  {auction.quantity && (
                    <div>
                      <span className="text-gray-600">Quantity:</span>
                      <div className="font-medium">{auction.quantity}</div>
                    </div>
                  )}
                  {auction.winner_vendor_email && (
                    <div className="col-span-2">
                      <span className="text-gray-600">Winner:</span>
                      <div className="font-medium flex items-center gap-1">
                        <Crown className="h-3 w-3 text-yellow-500" />
                        {auction.winner_vendor_email}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}