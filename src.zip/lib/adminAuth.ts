// Admin authentication storage and validation
// In production, this would be in a backend database

interface AdminAccount {
  email: string;
  name: string;
  password: string; // In production, this would be hashed
  role: 'owner' | 'global_admin' | 'internal_user';
  createdAt: number;
}

const STORAGE_KEY = 'speed_sourcing_admins';

// Preset accounts
const OWNER_EMAIL = 'mary.owner@emerson.com';
const OWNER_PASSWORD = 'Emerson!';
const OWNER_NAME = 'Mary Owner';

const GLOBAL_ADMIN_EMAIL = 'mary.admin@emerson.com';
const GLOBAL_ADMIN_PASSWORD = 'Emerson!';
const GLOBAL_ADMIN_NAME = 'Mary Admin';

// Initialize preset accounts if not exists
function initializePresetAccounts() {
  const admins = getAllAdmins();
  
  // Check if owner exists
  const ownerExists = admins.some(a => a.email === OWNER_EMAIL);
  if (!ownerExists) {
    admins.push({
      email: OWNER_EMAIL,
      name: OWNER_NAME,
      password: OWNER_PASSWORD,
      role: 'owner',
      createdAt: Date.now()
    });
  }
  
  // Check if global admin exists
  const globalAdminExists = admins.some(a => a.email === GLOBAL_ADMIN_EMAIL);
  if (!globalAdminExists) {
    admins.push({
      email: GLOBAL_ADMIN_EMAIL,
      name: GLOBAL_ADMIN_NAME,
      password: GLOBAL_ADMIN_PASSWORD,
      role: 'global_admin',
      createdAt: Date.now()
    });
  }
  
  saveAdmins(admins);
}

function getAllAdmins(): AdminAccount[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading admin accounts:', error);
    return [];
  }
}

function saveAdmins(admins: AdminAccount[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(admins));
  } catch (error) {
    console.error('Error saving admin accounts:', error);
  }
}

export function isOwner(email: string): boolean {
  return email.toLowerCase() === OWNER_EMAIL.toLowerCase();
}

export function isGlobalAdmin(email: string): boolean {
  return email.toLowerCase() === GLOBAL_ADMIN_EMAIL.toLowerCase();
}

export function getAdminAccount(email: string): AdminAccount | null {
  initializePresetAccounts();
  const admins = getAllAdmins();
  return admins.find(a => a.email.toLowerCase() === email.toLowerCase()) || null;
}

export function createAdminAccount(email: string, name: string, password: string): { success: boolean; error?: string; account?: AdminAccount } {
  initializePresetAccounts();
  
  // Validate email
  if (!email.toLowerCase().endsWith('@emerson.com')) {
    return { success: false, error: 'Email must be an @emerson.com address' };
  }

  // Validate name
  if (!name || name.trim().length < 2) {
    return { success: false, error: 'Please provide your full name' };
  }

  // Validate password
  if (password.length < 6) {
    return { success: false, error: 'Password must be at least 6 characters' };
  }

  // Check if account already exists
  const existing = getAdminAccount(email);
  if (existing) {
    return { success: false, error: 'An account with this email already exists. Please log in instead.' };
  }

  // Create new account (always as internal_user)
  const newAccount: AdminAccount = {
    email: email.toLowerCase(),
    name: name.trim(),
    password,
    role: 'internal_user',
    createdAt: Date.now()
  };

  const admins = getAllAdmins();
  admins.push(newAccount);
  saveAdmins(admins);

  return { success: true, account: newAccount };
}

export function validateAdminLogin(email: string, password: string): { success: boolean; error?: string; account?: AdminAccount } {
  initializePresetAccounts();
  
  const account = getAdminAccount(email);
  
  if (!account) {
    return { success: false, error: 'No account found with this email. Please sign up first.' };
  }

  if (account.password !== password) {
    return { success: false, error: 'Incorrect password. Please try again.' };
  }

  return { success: true, account };
}

export function listAllAdmins(): AdminAccount[] {
  initializePresetAccounts();
  return getAllAdmins();
}

export function getRoleName(role: 'owner' | 'global_admin' | 'internal_user'): string {
  switch (role) {
    case 'owner':
      return 'Owner';
    case 'global_admin':
      return 'Global Administrator';
    case 'internal_user':
      return 'Internal User';
  }
}

export function hasGlobalAccess(role: 'owner' | 'global_admin' | 'internal_user'): boolean {
  return role === 'owner' || role === 'global_admin';
}

export function canDelete(role: 'owner' | 'global_admin' | 'internal_user'): boolean {
  return role === 'owner';
}
