import { projectId, publicAnonKey } from '/utils/supabase/info';

// Get the correct API base URL
export function getApiUrl(path: string): string {
  // Always use direct Supabase URL in Figma Make environment
  // The Vite proxy doesn't work in Figma's preview iframe
  return `https://${projectId}.supabase.co/functions/v1${path}`;
}

// Helper function for API calls with proper headers and error handling
export async function apiCall(path: string, options: RequestInit = {}) {
  const url = getApiUrl(path);
  
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    ...options.headers,
  };

  try {
    const response = await fetch(url, {
      ...options,
      headers,
    });

    // Check if response is JSON
    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      // If not JSON, try to get text for error message
      const text = await response.text();
      console.error('Non-JSON response from server:', {
        url,
        status: response.status,
        statusText: response.statusText,
        contentType,
        body: text.substring(0, 500) // Log first 500 chars
      });
      
      throw new Error(`Server returned ${response.status}: Expected JSON but got ${contentType || 'unknown content type'}. The Edge Function may not be deployed.`);
    }

    return response;
  } catch (error) {
    console.error('API call failed:', {
      url,
      error: error instanceof Error ? error.message : String(error)
    });
    throw error;
  }
}